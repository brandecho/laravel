"use strict";

var app = angular.module('ng-laravel');
app.controller('profileCtrl',function($scope){

});
