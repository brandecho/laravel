"use strict";

var app = angular.module('ng-laravel');
app.controller('ProfileCtrl',function($scope){

});
