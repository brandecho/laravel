<h3>You are receiving this e-mail because you requested resetting your password to yeptemplate.com</h3>
Please click this URL to reset your password: <br>
<a href="{{ url('../../angular-frontend/#/forget/reset/'.$token) }}">Reset Password Link</a>
<br>
<br>
Thanks
